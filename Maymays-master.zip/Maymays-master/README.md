# Discord Bot for Oldschool Runescape
*Credit to RSBuddy for their item database*